import '../../App.css'
// import { useState, useEffect } from "react";

const Home = (props) => {
  // const [name, setName] = useState("");
  // const [email, setEmail] = useState("");

  // useEffect(() => {
  //   setName("Dass TAs");
  // }, []);

  return <div className="content">Welcome to IIITH Canteen Portal</div>;
};

export default Home;
